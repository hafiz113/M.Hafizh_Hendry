<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit();
}
$conn = new mysqli("localhost", "root", "", "marketplace");

$id = intval($_GET['id']);
$username = $_SESSION['username'];

$res = $conn->query("SELECT posts.photo, users.id AS user_id FROM posts JOIN users ON posts.user_id = users.id WHERE posts.id=$id");
$post = $res->fetch_assoc();

if (!$post) {
    echo "Barang tidak ditemukan.";
    exit();
}

$resUser = $conn->query("SELECT id FROM users WHERE username='$username'");
$user = $resUser->fetch_assoc();

if ($user['id'] != $post['user_id']) {
    echo "Kamu tidak berhak menghapus barang ini.";
    exit();
}

if ($post['photo'] && file_exists("uploads/" . $post['photo'])) {
    unlink("uploads/" . $post['photo']);
}

$conn->query("DELETE FROM posts WHERE id=$id");
header("Location: dashboard.php");
exit();
?>
