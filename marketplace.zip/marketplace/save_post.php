<?php
session_start();
include 'db.php';

$name = $_POST['name'];
$desc = $_POST['description'];
$price = $_POST['price'];

$filename = $_FILES['image']['name'];
$tmpname = $_FILES['image']['tmp_name'];
$target = "uploads/" . basename($filename);
move_uploaded_file($tmpname, $target);

$query = "INSERT INTO products (name, description, price, image) 
          VALUES ('$name', '$desc', '$price', '$filename')";
mysqli_query($conn, $query);

header("Location: dashboard.php");
?>