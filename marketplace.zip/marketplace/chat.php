<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit();
}
$conn = new mysqli("localhost", "root", "", "marketplace");

$username = $_SESSION['username'];
$res = $conn->query("SELECT id FROM users WHERE username='$username'");
$user = $res->fetch_assoc();
$sender_id = $user['id'];

if (!isset($_GET['user_id'])) {
    echo "User chat tidak ditemukan.";
    exit();
}
$receiver_id = intval($_GET['user_id']);

$resUser = $conn->query("SELECT username FROM users WHERE id=$receiver_id");
$userReceiver = $resUser->fetch_assoc();
if (!$userReceiver) {
    echo "User chat tidak ditemukan.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = $_POST['message'];
    $stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $sender_id, $receiver_id, $message);
    $stmt->execute();
    header("Location: chat.php?user_id=$receiver_id");
    exit();
}

$sql = "SELECT messages.*, u1.username AS sender_name, u2.username AS receiver_name
        FROM messages
        JOIN users u1 ON messages.sender_id = u1.id
        JOIN users u2 ON messages.receiver_id = u2.id
        WHERE (sender_id=$sender_id AND receiver_id=$receiver_id)
           OR (sender_id=$receiver_id AND receiver_id=$sender_id)
        ORDER BY created_at ASC";
$messages = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Chat dengan <?php echo htmlspecialchars($userReceiver['username']); ?></title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
<a href="chat_list.php">Kembali ke Daftar Chat</a> | <a href="dashboard.php">Dashboard</a>
<h2>Chat dengan <?php echo htmlspecialchars($userReceiver['username']); ?></h2>

<div style="border:1px solid #ccc; padding:10px; height:300px; overflow-y:scroll; background:#f9f9f9;">
    <?php
    if ($messages->num_rows > 0) {
        while ($msg = $messages->fetch_assoc()) {
            $sender = $msg['sender_name'];
            $text = htmlspecialchars($msg['message']);
            echo "<p><strong>$sender:</strong> $text <small>(" . $msg['created_at'] . ")</small></p>";
        }
    } else {
        echo "<p>Belum ada pesan.</p>";
    }
    ?>
</div>

<form action="" method="POST">
    <textarea name="message" rows="3" required placeholder="Tulis pesan..."></textarea><br>
    <button type="submit">Kirim</button>
</form>

</body>
</html>
