<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "marketplace");
$username = $_SESSION['username'];

$res = $conn->query("SELECT id FROM users WHERE username='$username'");
$user = $res->fetch_assoc();
$user_id = $user['id'];

$posts = $conn->query("SELECT posts.*, users.username FROM posts JOIN users ON posts.user_id = users.id ORDER BY posts.created_at DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Marketplace</title>
    <link rel="stylesheet" href="css2.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>

<div class="top-bar">
    <h2>selamat belanja <?php echo htmlspecialchars($username); ?></h2>
    <div class="button-group">
        <a href="post_barang.php" class="btn blue">+ Posting</a>
        <a href="chat_list.php" class="btn green">💬 Chat</a>
        <a href="logout.php" class="btn red">⏻ Logout</a>
    </div>
</div>

<h3>Daftar Barang </h3>

<div class="post-grid">
<?php
if ($posts->num_rows > 0) {
    while ($row = $posts->fetch_assoc()) {
        echo "<div class='post-card'>";
        if ($row['photo']) {
            echo "<img class='post-image' src='uploads/" . htmlspecialchars($row['photo']) . "' alt='Foto Barang'>";
        }
        echo "<div class='post-content'>";
        echo "<h4 class='post-title'>" . htmlspecialchars($row['title']) . "</h4>";
        echo "<p class='post-description'>" . nl2br(htmlspecialchars($row['description'])) . "</p>";
        echo "<p class='post-meta'>📦 Dipost oleh <strong>" . htmlspecialchars($row['username']) . "</strong><br><small>⏰ " . $row['created_at'] . "</small></p>";
      if ($row['user_id'] == $user_id) {
    echo "<a class='btn-edit' href='edit_barang.php?id=" . $row['id'] . "'>✏️ Edit</a> ";
    echo "<a class='btn-delete' href='hapus_barang.php?id=" . $row['id'] . "' onclick='return confirm(\"Yakin hapus?\");'>🗑️ Hapus</a>";
}

        echo "</div></div>";
    }
} else {
    echo "<p>Belum ada barang yang dipost.</p>";
}
?>
</div>

</body>
</html>
