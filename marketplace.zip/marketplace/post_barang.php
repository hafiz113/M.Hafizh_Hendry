<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit();
}
$conn = new mysqli("localhost", "root", "", "marketplace");
$username = $_SESSION['username'];
$res = $conn->query("SELECT id FROM users WHERE username='$username'");
$user = $res->fetch_assoc();
$user_id = $user['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $photo_name = '';

    if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
        $tmp_name = $_FILES['photo']['tmp_name'];
        $photo_name = time() . "_" . basename($_FILES['photo']['name']);
        move_uploaded_file($tmp_name, "uploads/" . $photo_name);
    }

    $stmt = $conn->prepare("INSERT INTO posts (user_id, title, description, photo) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $user_id, $title, $description, $photo_name);
    $stmt->execute();

    header("Location: dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <title>Post Barang Baru</title>
   <link rel="stylesheet" href="post.css" />

</head>
<body>
<h2>Posting Barang Baru</h2>
<form action="" method="POST" enctype="multipart/form-data">
    <input type="text" name="title" placeholder="Judul Barang" required><br>
    <textarea name="description" placeholder="Deskripsi Barang" rows="4" required></textarea><br>
    <input type="file" name="photo" accept="image/*"><br>
    <button type="submit">Post</button>
</form>
<a href="dashboard.php">Kembali ke Dashboard</a>
</body>
</html>
