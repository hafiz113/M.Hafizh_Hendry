<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit();
}
$conn = new mysqli("localhost", "root", "", "marketplace");
$username = $_SESSION['username'];

$res = $conn->query("SELECT id FROM users WHERE username='$username'");
$user = $res->fetch_assoc();
$user_id = $user['id'];

$users = $conn->query("SELECT id, username FROM users WHERE id != $user_id");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Daftar Chat</title>
  <link rel="stylesheet" href="style1.css" />
</head>
<body>
<h2>Daftar Pengguna untuk Chat</h2>
<a href="dashboard.php">Kembali ke Dashboard</a><br><br>
<ul>
<?php
while ($u = $users->fetch_assoc()) {
    echo "<li><a href='chat.php?user_id=" . $u['id'] . "'>" . htmlspecialchars($u['username']) . "</a></li>";
}
?>
</ul>
</body>
</html>
