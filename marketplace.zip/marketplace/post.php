<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Posting Barang</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">
    <h2>Posting Barang</h2>
    <form action="save_post.php" method="POST" enctype="multipart/form-data">
      <input type="text" name="name" placeholder="Nama Barang" required>
      <textarea name="description" placeholder="Deskripsi" required></textarea>
      <input type="number" name="price" placeholder="Harga" required>
      <input type="file" name="image" accept="image/*" required>
      <button type="submit">Posting</button>
    </form>
  </div>
</body>
</html>