<?php
$conn = new mysqli("localhost", "root", "", "marketplace");

$username = $_POST['username'];
$password = $_POST['password'];

// Cek username sudah ada atau belum
$res = $conn->prepare("SELECT id FROM users WHERE username = ?");
$res->bind_param("s", $username);
$res->execute();
$res->store_result();

if ($res->num_rows > 0) {
    echo "Username sudah dipakai, silakan coba yang lain.";
    exit();
}

$stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
$stmt->bind_param("ss", $username, $password);
$stmt->execute();

header("Location: index.html");
?>
