<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit();
}
$conn = new mysqli("localhost", "root", "", "marketplace");
$id = intval($_GET['id']);

// Ambil user login
$username = $_SESSION['username'];
$res = $conn->query("SELECT id FROM users WHERE username='$username'");
$user = $res->fetch_assoc();
$user_id = $user['id'];

// Ambil data barang
$res = $conn->query("SELECT * FROM posts WHERE id=$id AND user_id=$user_id");
if ($res->num_rows == 0) {
    echo "Barang tidak ditemukan atau Anda tidak punya akses.";
    exit();
}
$barang = $res->fetch_assoc();

// Jika form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $stmt = $conn->prepare("UPDATE posts SET title=?, description=? WHERE id=? AND user_id=?");
    $stmt->bind_param("ssii", $title, $description, $id, $user_id);
    $stmt->execute();
    header("Location: dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <title>Edit Barang</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
    <h2>Edit Barang</h2>
    <form action="" method="POST">
        <input type="text" name="title" value="<?php echo htmlspecialchars($barang['title']); ?>" required><br><br>
        <textarea name="description" rows="5" required><?php echo htmlspecialchars($barang['description']); ?></textarea><br><br>
        <button type="submit">Simpan Perubahan</button>
        <a href="dashboard.php">Batal</a>
    </form>
</body>
</html>
